# Cigarette Market Dataset

This repository contains a small, structured dataset extracted from the public report page *"Cigarette Market"* by Next Move Strategy Consulting (report page: https://www.nextmsc.com/report/cigarette-market-3644).

## Contents
- `dataset.csv` — a one-row CSV capturing the main figures and segments from the public report.
- `metadata.json` — machine-readable metadata describing fields and provenance.
- `README.md` — this file.

## About the source
Key figures in the dataset (market sizes, CAGR, segments, and key players) were taken from the Next Move Strategy Consulting public report page. See the original page for full tables, charts, and the downloadable PDF. The dataset is intended for educational and prototyping use, not as a substitute for the full paid report.

## Fields
See `metadata.json` for field descriptions. In brief:
- `Market_Size_2024_USD_billion`, `Market_Size_2025_USD_billion`, `Market_Projection_2030_USD_billion` — reported market values.
- `CAGR_2025_2030_percent` — projected CAGR cited on the page.
- `Segments` — the segmentation categories listed on the report page.
- `Key_Players` — companies explicitly listed under "Key Players" on the report page.

## License & Attribution
This dataset is a derived summary of a commercial report page and is provided for demonstration purposes only. Please attribute the original content to Next Move Strategy Consulting and visit their site for the full report.

## Reference README style
This README was written using the style and structure of the example README at:
https://github.com/Sanyukta678/immunoglobulin-market-dataset/blob/main/README.md
